# PHASE 2: TYPE SYSTEM COMPREHENSIVE AUDIT & CONSOLIDATION PLAN

## EXECUTIVE SUMMARY

The Starcom HUD codebase contains **620+ type definitions** across **183 TypeScript files**. This audit reveals significant type fragmentation, redundancy, and inconsistencies that must be systematically consolidated to achieve production-ready architecture.

**Critical Issues Identified:**
- Multiple overlapping type systems for similar concepts
- Inconsistent naming conventions and patterns
- Legacy type compatibility utilities still in use
- Mixed type import patterns and circular dependencies
- Redundant interface definitions across different modules

---

## CURRENT TYPE SYSTEM LANDSCAPE

### Core Type Categories

#### 1. **COMMAND & CONTROL TYPES**
- **Primary**: `src/context/UnifiedGlobalCommandContext.tsx` (784 lines)
- **Legacy**: `src/context/EnhancedGlobalCommandContext.tsx` ⚠️ PENDING REMOVAL
- **Legacy**: `src/context/GlobalCommandContext.tsx` ⚠️ PENDING REMOVAL
- **Compatibility**: `src/utils/typeCompatibility.ts` ⚠️ PENDING REMOVAL

**Unified Types:**
```typescript
export type OperationMode = 'PLANETARY' | 'SPACE' | 'CYBER' | 'STELLAR';
export type DisplayMode = '3D_GLOBE' | 'TIMELINE_VIEW' | 'NODE_GRAPH';
export type PriorityLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
```

#### 2. **AI & INTELLIGENCE TYPES**
- **Location**: `src/types/ai.ts` (360+ lines)
- **Status**: ✅ WELL-STRUCTURED, COMPREHENSIVE

**Key Types:**
```typescript
export type ThreatSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type ThreatType = 'CYBER' | 'SPACE' | 'PLANETARY' | 'STELLAR' | 'HYBRID';
export interface AIState // Comprehensive state management
export type AIActionType // Union type for actions
```

#### 3. **COLLABORATION TYPES**
- **Location**: `src/types/collaboration.ts` (380+ lines)
- **Status**: ✅ WELL-STRUCTURED, COMPREHENSIVE

**Key Types:**
```typescript
export type AgencyType = 'SOCOM' | 'SPACE_FORCE' | 'CYBER_COMMAND' | 'NSA' | 'DIA' | 'CIA';
export type ClearanceLevel = 'UNCLASSIFIED' | 'CONFIDENTIAL' | 'SECRET' | 'TOP_SECRET' | 'SCI';
export interface CollaborationState // Complete collaboration state
```

#### 4. **ADAPTIVE INTERFACE TYPES**
- **Location**: `src/types/adaptive.ts` (445+ lines)
- **Status**: ⚠️ NEEDS CONSOLIDATION WITH UNIFIED CONTEXT

**Key Types:**
```typescript
export type OperatorRole = 'COMMANDER' | 'ANALYST' | 'OPERATOR' | 'SPECIALIST' | 'TRAINEE';
export type InterfaceComplexity = 'MINIMAL' | 'STANDARD' | 'ADVANCED' | 'EXPERT';
export interface AdaptiveInterfaceState // Overlaps with unified context
```

#### 5. **DOMAIN-SPECIFIC TYPES**

**Space Weather** (`src/types/spaceWeather.ts` - 83 lines):
```typescript
export interface NOAAElectricFieldData
export interface ElectricFieldVector
export interface SpaceWeatherAlert
```

**Intel Market** (`src/types/intel_market.ts` - 101 lines):
```typescript
export const IDL // Anchor/Solana program interface
```

**Conflict Data** (`src/types/ucdpTypes.ts` - 38 lines):
```typescript
export interface UCDPEvent
export interface Conflict
```

**Time Data** (`src/types/TimeDataTypes.ts` - 4 lines):
```typescript
export interface CacheEntry // ⚠️ TOO GENERIC, USES 'any'
```

---

## TYPE FRAGMENTATION ANALYSIS

### Redundant/Overlapping Types

#### 1. **Interface Complexity Duplication**
- `InterfaceComplexity` in `adaptive.ts`
- `UIComplexity` in unified context
- Type mapping utilities in `typeCompatibility.ts`

#### 2. **State Management Patterns**
- `AdaptiveInterfaceState` (adaptive.ts)
- `UnifiedGlobalCommandState` (unified context)
- Legacy enhanced states (multiple contexts)

#### 3. **Action Type Patterns**
- `AIActionType` (ai.ts)
- `CollaborationAction` (collaboration.ts)
- `AdaptiveInterfaceAction` (adaptive.ts)
- Unified actions in context

#### 4. **Bridge/Compatibility Types**
Multiple bridge contexts and compatibility utilities indicating architectural fragmentation.

---

## CONSOLIDATION STRATEGY

### Phase 2A: Type Audit Completion ✅ CURRENT PHASE

**Objectives:**
1. ✅ Complete comprehensive type mapping
2. ✅ Identify all redundancies and conflicts
3. ✅ Document current usage patterns
4. 🔄 Create migration roadmap

### Phase 2B: Core Type Standardization

**Tasks:**
1. **Establish Unified Type Patterns**
   - Standardize naming conventions
   - Consolidate action type patterns
   - Unify state interface structures

2. **Create Master Type Registry**
   - `src/types/index.ts` - Central export hub
   - `src/types/core/` - Core command types
   - `src/types/features/` - Feature-specific types
   - `src/types/data/` - Data layer types

3. **Remove Type Compatibility Layer**
   - Eliminate `typeCompatibility.ts`
   - Direct type usage everywhere
   - No more bridge patterns

### Phase 2C: Import Pattern Standardization

**Current Issues:**
```typescript
// Inconsistent patterns found:
import type { InterfaceComplexity } from '../types/adaptive';
import { useAdaptiveInterface } from './useAdaptiveInterface';
import type { ThreatIndicator } from '../types/ai';
```

**Target Pattern:**
```typescript
// Standardized pattern:
import type { 
  InterfaceComplexity,
  ThreatIndicator,
  CollaborationState 
} from '@/types';
import { useUnifiedCommand } from '@/hooks';
```

### Phase 2D: Legacy Type Elimination

**Files for Removal:**
- ❌ `src/context/EnhancedGlobalCommandContext.tsx`
- ❌ `src/context/GlobalCommandContext.tsx`
- ❌ `src/context/EnhancedGlobalCommandDefaults.ts`
- ❌ `src/context/EnhancedGlobalCommandHooks.ts`
- ❌ `src/context/EnhancedGlobalCommandCollaborationHooks.ts`
- ❌ `src/utils/typeCompatibility.ts`
- ❌ `src/context/AdaptiveGlobalCommandBridgeContext.ts`

---

## SPECIFIC TYPE ISSUES TO RESOLVE

### 1. **Generic 'any' Types**
```typescript
// ❌ Current (TimeDataTypes.ts):
export interface CacheEntry {
  timestamp: number;
  data: any[]; // Replace with proper generic
}

// ✅ Target:
export interface CacheEntry<T = unknown> {
  timestamp: number;
  data: T[];
}
```

### 2. **Inconsistent Enum Patterns**
```typescript
// ❌ Current - Mixed string unions and enums
export type OperationMode = 'PLANETARY' | 'SPACE' | 'CYBER' | 'STELLAR';
export type ThreatType = 'CYBER' | 'SPACE' | 'PLANETARY' | 'STELLAR' | 'HYBRID';

// ✅ Target - Consistent pattern with namespace collision resolution
export namespace Command {
  export type OperationMode = 'PLANETARY' | 'SPACE' | 'CYBER' | 'STELLAR';
}
export namespace AI {
  export type ThreatType = 'CYBER' | 'SPACE' | 'PLANETARY' | 'STELLAR' | 'HYBRID';
}
```

### 3. **Interface vs Type Alias Inconsistency**
Need consistent pattern for when to use `interface` vs `type`.

---

## MIGRATION EXECUTION PLAN

### Week 1: Foundation Setup
1. Create new type structure in `src/types/`
2. Set up central exports and path aliases
3. Create type migration utilities

### Week 2: Core Type Migration
1. Migrate unified context types
2. Consolidate action patterns
3. Update all core component imports

### Week 3: Feature Type Integration
1. Integrate AI, collaboration, adaptive types
2. Remove compatibility layers
3. Update all feature component imports

### Week 4: Legacy Cleanup
1. Remove legacy context files
2. Remove bridge patterns
3. Final validation and testing

---

## SUCCESS METRICS

### Quantitative Goals
- **Type File Count**: Reduce from 183 files with types to <50 focused type files
- **Type Definitions**: Consolidate 620+ definitions to <300 non-redundant types
- **Import Statements**: Standardize all 400+ type imports to unified pattern
- **Build Time**: Improve TypeScript compilation speed by 25%

### Qualitative Goals
- Zero type compatibility utilities needed
- Single source of truth for each type concept
- Consistent naming and pattern usage
- Clear type documentation and JSDoc coverage

---

## RISK MITIGATION

### Build Safety
- Incremental migration with continuous builds
- Comprehensive test coverage during migration
- Rollback checkpoints at each major step

### Development Continuity
- Staged migration allows parallel feature development
- Clear migration documentation for team
- Type compatibility layer maintained until full migration

---

## CONCLUSION

The type system audit reveals significant opportunities for consolidation and standardization. The current 620+ type definitions across 183 files contain substantial redundancy and inconsistency. 

Phase 2 will systematically consolidate these into a clean, maintainable type architecture supporting the unified context system established in Phase 1. This will provide the foundation for advanced features in subsequent phases while maintaining full type safety and developer experience.

**Next Action**: Proceed with Phase 2B - Core Type Standardization implementation.
